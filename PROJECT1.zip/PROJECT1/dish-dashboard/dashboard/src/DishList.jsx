// src/DishList.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Button, Spinner, Alert } from 'react-bootstrap';

const DishList = () => {
  const [dishes, setDishes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    
    axios.get('http://localhost:3001/api/dishes')
      .then(res => {
        setDishes(res.data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching dishes:', err);
        setError('Error fetching dishes');
        setLoading(false);
      });
  }, []);

  const togglePublishStatus = (dishId) => {
    axios.post(`http://localhost:3001/api/dishes/${dishId}/toggle-publish`)
      .then(res => {
        // Update state to reflect the change
        setDishes(prevDishes => {
          return prevDishes.map(dish => {
            if (dish.dishId === dishId) {
              return { ...dish, isPublished: !dish.isPublished };
            }
            return dish;
          });
        });
      })
      .catch(err => {
        console.error('Error toggling publish status:', err);
        setError('Error toggling publish status');
      });
  };

  if (loading) {
    return <Spinner animation="border" role="status"><span className="visually-hidden">Loading...</span></Spinner>;
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  if (!Array.isArray(dishes)) {
    return <Alert variant="danger">Unexpected response format</Alert>;
  }

  return (
    <div className="dish-list d-flex flex-wrap">
      {dishes.map(dish => (
        <Card key={dish.dishId} style={{ width: '18rem', margin: '10px' }}>
          <Card.Img variant="top" src={dish.imageUrl} />
          <Card.Body>
            <Card.Title>{dish.dishName}</Card.Title>
            <Card.Text>
              Published: {dish.isPublished ? 'Yes' : 'No'}
            </Card.Text>
            <Button onClick={() => togglePublishStatus(dish.dishId)}>
              Toggle Publish
            </Button>
          </Card.Body>
        </Card>
      ))}
    </div>
  );
};

export default DishList;
