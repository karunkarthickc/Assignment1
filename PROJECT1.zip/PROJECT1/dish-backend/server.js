const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3001;


app.use(bodyParser.json());


app.use(cors({
    origin: 'http://localhost:5173'
}));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'yourdatabase'
});


db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('MySQL connected...');
});

app.get('/api/dishes', (req, res) => {
    const sql = 'SELECT * FROM dishes';
    db.query(sql, (err, result) => {
        if (err) throw err;
        res.json(result);
    });
});


app.post('/api/dishes/:dishId/toggle-publish', (req, res) => {
    const dishId = req.params.dishId;
    const sql = 'UPDATE dishes SET isPublished = NOT isPublished WHERE dishId = ?';
    db.query(sql, [dishId], (err, result) => {
        if (err) throw err;
        res.send('Dish status updated successfully.');
    });
});


app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
